var counter=2;
setInterval( function(){  document.title="Oops!!"; },1000);